package controller;

public class controllerConfig {

//	public static final int OBJECT_TYPE_CODE 	= 1;
//	public static final int OBJECT_TYPE_USECASE  = 2;
//	public static final int OBJECT_TYPE_UML		= 3;
}
