package controller;

public class clObjectValidator extends IFObjectValidator{

	@Override
	public void loader() {
		// Load class using the feed
		
	}

}
